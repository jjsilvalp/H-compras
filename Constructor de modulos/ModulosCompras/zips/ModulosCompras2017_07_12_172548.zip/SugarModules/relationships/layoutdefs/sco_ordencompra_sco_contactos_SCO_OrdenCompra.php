<?php
 // created: 2017-07-12 17:25:31
$layout_defs["SCO_OrdenCompra"]["subpanel_setup"]['sco_ordencompra_sco_contactos'] = array (
  'order' => 100,
  'module' => 'SCO_Contactos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SCO_ORDENCOMPRA_SCO_CONTACTOS_FROM_SCO_CONTACTOS_TITLE',
  'get_subpanel_data' => 'sco_ordencompra_sco_contactos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
