<?php
// created: 2017-07-12 17:25:44
$dictionary["SCO_ProductosCompras"]["fields"]["sco_proveedor_sco_productoscompras"] = array (
  'name' => 'sco_proveedor_sco_productoscompras',
  'type' => 'link',
  'relationship' => 'sco_proveedor_sco_productoscompras',
  'source' => 'non-db',
  'module' => 'SCO_Proveedor',
  'bean_name' => false,
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PROVEEDOR_TITLE',
  'id_name' => 'sco_proveedor_sco_productoscomprassco_proveedor_ida',
);
$dictionary["SCO_ProductosCompras"]["fields"]["sco_proveedor_sco_productoscompras_name"] = array (
  'name' => 'sco_proveedor_sco_productoscompras_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PROVEEDOR_TITLE',
  'save' => true,
  'id_name' => 'sco_proveedor_sco_productoscomprassco_proveedor_ida',
  'link' => 'sco_proveedor_sco_productoscompras',
  'table' => 'sco_proveedor',
  'module' => 'SCO_Proveedor',
  'rname' => 'name',
);
$dictionary["SCO_ProductosCompras"]["fields"]["sco_proveedor_sco_productoscomprassco_proveedor_ida"] = array (
  'name' => 'sco_proveedor_sco_productoscomprassco_proveedor_ida',
  'type' => 'link',
  'relationship' => 'sco_proveedor_sco_productoscompras',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOSCOMPRAS_TITLE',
);
