<?php
// created: 2017-07-12 17:25:32
$dictionary["SCO_OrdenCompra"]["fields"]["sco_ordencompra_sco_documentos"] = array (
  'name' => 'sco_ordencompra_sco_documentos',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_documentos',
  'source' => 'non-db',
  'module' => 'SCO_documentos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_DOCUMENTOS_FROM_SCO_DOCUMENTOS_TITLE',
);
