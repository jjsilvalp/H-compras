<?php
// created: 2017-07-12 17:25:34
$dictionary["SCO_OrdenCompra"]["fields"]["sco_ordencompra_sco_plandepagos"] = array (
  'name' => 'sco_ordencompra_sco_plandepagos',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_plandepagos',
  'source' => 'non-db',
  'module' => 'SCO_PlandePagos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_PLANDEPAGOS_FROM_SCO_PLANDEPAGOS_TITLE',
);
