<?php
// created: 2017-07-12 17:25:32
$dictionary["SCO_documentos"]["fields"]["sco_ordencompra_sco_documentos"] = array (
  'name' => 'sco_ordencompra_sco_documentos',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_documentos',
  'source' => 'non-db',
  'module' => 'SCO_OrdenCompra',
  'bean_name' => false,
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_DOCUMENTOS_FROM_SCO_ORDENCOMPRA_TITLE',
  'id_name' => 'sco_ordencompra_sco_documentossco_ordencompra_ida',
);
$dictionary["SCO_documentos"]["fields"]["sco_ordencompra_sco_documentos_name"] = array (
  'name' => 'sco_ordencompra_sco_documentos_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_DOCUMENTOS_FROM_SCO_ORDENCOMPRA_TITLE',
  'save' => true,
  'id_name' => 'sco_ordencompra_sco_documentossco_ordencompra_ida',
  'link' => 'sco_ordencompra_sco_documentos',
  'table' => 'sco_ordencompra',
  'module' => 'SCO_OrdenCompra',
  'rname' => 'name',
);
$dictionary["SCO_documentos"]["fields"]["sco_ordencompra_sco_documentossco_ordencompra_ida"] = array (
  'name' => 'sco_ordencompra_sco_documentossco_ordencompra_ida',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_documentos',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_DOCUMENTOS_FROM_SCO_DOCUMENTOS_TITLE',
);
