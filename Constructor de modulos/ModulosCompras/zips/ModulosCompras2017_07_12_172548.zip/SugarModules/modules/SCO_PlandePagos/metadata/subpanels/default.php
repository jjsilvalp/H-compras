<?php
$module_name='SCO_PlandePagos';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SCO_PlandePagos',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'ppg_tipo' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'vname' => 'LBL_PPG_TIPO',
      'width' => '10%',
    ),
    'ppg_hito' => 
    array (
      'type' => 'varchar',
      'vname' => 'LBL_PPG_HITO',
      'width' => '10%',
      'default' => true,
    ),
    'ppg_porc' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_PPG_PORC',
      'width' => '10%',
      'default' => true,
    ),
    'ppg_monto' => 
    array (
      'type' => 'currency',
      'vname' => 'LBL_PPG_MONTO',
      'currency_format' => true,
      'width' => '10%',
      'default' => true,
    ),
    'currency_id' => 
    array (
      'type' => 'currency_id',
      'studio' => 'visible',
      'vname' => 'LBL_CURRENCY',
      'width' => '10%',
      'default' => true,
    ),
  ),
);