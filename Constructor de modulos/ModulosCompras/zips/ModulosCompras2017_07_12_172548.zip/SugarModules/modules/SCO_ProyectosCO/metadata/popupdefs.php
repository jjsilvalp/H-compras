<?php
$popupMeta = array (
    'moduleMain' => 'SCO_ProyectosCO',
    'varName' => 'SCO_ProyectosCO',
    'orderBy' => 'sco_proyectosco.name',
    'whereClauses' => array (
  'name' => 'sco_proyectosco.name',
  'proyc_tipo' => 'sco_proyectosco.proyc_tipo',
  'proyc_codsap' => 'sco_proyectosco.proyc_codsap',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'proyc_tipo',
  5 => 'proyc_codsap',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'proyc_tipo' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PROYC_TIPO',
    'width' => '10%',
    'name' => 'proyc_tipo',
  ),
  'proyc_codsap' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PROYC_CODSAP ',
    'width' => '10%',
    'name' => 'proyc_codsap',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'PROYC_DESCRIPCION' => 
  array (
    'type' => 'text',
    'studio' => 'visible',
    'label' => 'LBL_PROYC_DESCRIPCION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
  'PROYC_TIPO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PROYC_TIPO',
    'width' => '10%',
    'default' => true,
  ),
  'PROYC_CODSAP' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PROYC_CODSAP ',
    'width' => '10%',
    'default' => true,
  ),
  'PROYC_ESTADO' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_PROYC_ESTADO',
    'width' => '10%',
    'default' => true,
  ),
),
);
