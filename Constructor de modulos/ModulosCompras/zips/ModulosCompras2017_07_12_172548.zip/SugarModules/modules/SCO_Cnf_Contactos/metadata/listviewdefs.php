<?php
$module_name = 'SCO_Cnf_Contactos';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CNFCO_DIV' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CNFCO_DIV',
    'width' => '10%',
    'default' => true,
  ),
  'CNFCO_REG' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CNFCO_REG',
    'width' => '10%',
    'default' => true,
  ),
);
?>
