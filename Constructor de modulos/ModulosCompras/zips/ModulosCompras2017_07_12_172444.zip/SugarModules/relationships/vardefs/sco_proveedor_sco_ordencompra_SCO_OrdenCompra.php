<?php
// created: 2017-07-12 17:24:39
$dictionary["SCO_OrdenCompra"]["fields"]["sco_proveedor_sco_ordencompra"] = array (
  'name' => 'sco_proveedor_sco_ordencompra',
  'type' => 'link',
  'relationship' => 'sco_proveedor_sco_ordencompra',
  'source' => 'non-db',
  'module' => 'SCO_Proveedor',
  'bean_name' => false,
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_ORDENCOMPRA_FROM_SCO_PROVEEDOR_TITLE',
  'id_name' => 'sco_proveedor_sco_ordencomprasco_proveedor_ida',
);
$dictionary["SCO_OrdenCompra"]["fields"]["sco_proveedor_sco_ordencompra_name"] = array (
  'name' => 'sco_proveedor_sco_ordencompra_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_ORDENCOMPRA_FROM_SCO_PROVEEDOR_TITLE',
  'save' => true,
  'id_name' => 'sco_proveedor_sco_ordencomprasco_proveedor_ida',
  'link' => 'sco_proveedor_sco_ordencompra',
  'table' => 'sco_proveedor',
  'module' => 'SCO_Proveedor',
  'rname' => 'name',
);
$dictionary["SCO_OrdenCompra"]["fields"]["sco_proveedor_sco_ordencomprasco_proveedor_ida"] = array (
  'name' => 'sco_proveedor_sco_ordencomprasco_proveedor_ida',
  'type' => 'link',
  'relationship' => 'sco_proveedor_sco_ordencompra',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_ORDENCOMPRA_FROM_SCO_ORDENCOMPRA_TITLE',
);
