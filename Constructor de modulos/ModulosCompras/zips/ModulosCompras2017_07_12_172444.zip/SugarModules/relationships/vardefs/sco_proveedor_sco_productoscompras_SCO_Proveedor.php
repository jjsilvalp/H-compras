<?php
// created: 2017-07-12 17:24:40
$dictionary["SCO_Proveedor"]["fields"]["sco_proveedor_sco_productoscompras"] = array (
  'name' => 'sco_proveedor_sco_productoscompras',
  'type' => 'link',
  'relationship' => 'sco_proveedor_sco_productoscompras',
  'source' => 'non-db',
  'module' => 'SCO_ProductosCompras',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOSCOMPRAS_TITLE',
);
