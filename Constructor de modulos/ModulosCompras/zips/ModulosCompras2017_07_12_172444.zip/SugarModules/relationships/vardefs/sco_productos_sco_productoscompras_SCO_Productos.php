<?php
// created: 2017-07-12 17:24:36
$dictionary["SCO_Productos"]["fields"]["sco_productos_sco_productoscompras"] = array (
  'name' => 'sco_productos_sco_productoscompras',
  'type' => 'link',
  'relationship' => 'sco_productos_sco_productoscompras',
  'source' => 'non-db',
  'module' => 'SCO_ProductosCompras',
  'bean_name' => false,
  'vname' => 'LBL_SCO_PRODUCTOS_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOSCOMPRAS_TITLE',
  'id_name' => 'sco_productos_sco_productoscomprassco_productoscompras_ida',
);
$dictionary["SCO_Productos"]["fields"]["sco_productos_sco_productoscompras_name"] = array (
  'name' => 'sco_productos_sco_productoscompras_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SCO_PRODUCTOS_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOSCOMPRAS_TITLE',
  'save' => true,
  'id_name' => 'sco_productos_sco_productoscomprassco_productoscompras_ida',
  'link' => 'sco_productos_sco_productoscompras',
  'table' => 'sco_productoscompras',
  'module' => 'SCO_ProductosCompras',
  'rname' => 'name',
);
$dictionary["SCO_Productos"]["fields"]["sco_productos_sco_productoscomprassco_productoscompras_ida"] = array (
  'name' => 'sco_productos_sco_productoscomprassco_productoscompras_ida',
  'type' => 'link',
  'relationship' => 'sco_productos_sco_productoscompras',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PRODUCTOS_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOS_TITLE',
);
