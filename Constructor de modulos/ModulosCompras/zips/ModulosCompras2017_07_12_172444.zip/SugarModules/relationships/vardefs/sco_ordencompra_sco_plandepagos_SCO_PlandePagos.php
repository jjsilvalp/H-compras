<?php
// created: 2017-07-12 17:24:30
$dictionary["SCO_PlandePagos"]["fields"]["sco_ordencompra_sco_plandepagos"] = array (
  'name' => 'sco_ordencompra_sco_plandepagos',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_plandepagos',
  'source' => 'non-db',
  'module' => 'SCO_OrdenCompra',
  'bean_name' => false,
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_PLANDEPAGOS_FROM_SCO_ORDENCOMPRA_TITLE',
  'id_name' => 'sco_ordencompra_sco_plandepagossco_ordencompra_ida',
);
$dictionary["SCO_PlandePagos"]["fields"]["sco_ordencompra_sco_plandepagos_name"] = array (
  'name' => 'sco_ordencompra_sco_plandepagos_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_PLANDEPAGOS_FROM_SCO_ORDENCOMPRA_TITLE',
  'save' => true,
  'id_name' => 'sco_ordencompra_sco_plandepagossco_ordencompra_ida',
  'link' => 'sco_ordencompra_sco_plandepagos',
  'table' => 'sco_ordencompra',
  'module' => 'SCO_OrdenCompra',
  'rname' => 'name',
);
$dictionary["SCO_PlandePagos"]["fields"]["sco_ordencompra_sco_plandepagossco_ordencompra_ida"] = array (
  'name' => 'sco_ordencompra_sco_plandepagossco_ordencompra_ida',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_plandepagos',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_PLANDEPAGOS_FROM_SCO_PLANDEPAGOS_TITLE',
);
