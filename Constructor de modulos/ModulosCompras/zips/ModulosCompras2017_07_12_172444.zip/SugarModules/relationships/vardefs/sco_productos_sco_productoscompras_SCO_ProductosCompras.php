<?php
// created: 2017-07-12 17:24:36
$dictionary["SCO_ProductosCompras"]["fields"]["sco_productos_sco_productoscompras"] = array (
  'name' => 'sco_productos_sco_productoscompras',
  'type' => 'link',
  'relationship' => 'sco_productos_sco_productoscompras',
  'source' => 'non-db',
  'module' => 'SCO_Productos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PRODUCTOS_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOS_TITLE',
);
