<?php
// created: 2017-07-12 17:24:31
$dictionary["SCO_OrdenCompra"]["fields"]["sco_ordencompra_sco_aprobadores"] = array (
  'name' => 'sco_ordencompra_sco_aprobadores',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_aprobadores',
  'source' => 'non-db',
  'module' => 'SCO_Aprobadores',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_APROBADORES_FROM_SCO_APROBADORES_TITLE',
);
