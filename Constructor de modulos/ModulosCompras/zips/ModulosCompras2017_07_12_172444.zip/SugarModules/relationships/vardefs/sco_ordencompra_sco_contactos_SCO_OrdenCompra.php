<?php
// created: 2017-07-12 17:24:29
$dictionary["SCO_OrdenCompra"]["fields"]["sco_ordencompra_sco_contactos"] = array (
  'name' => 'sco_ordencompra_sco_contactos',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_contactos',
  'source' => 'non-db',
  'module' => 'SCO_Contactos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_CONTACTOS_FROM_SCO_CONTACTOS_TITLE',
);
