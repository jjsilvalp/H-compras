<?php
// created: 2017-07-12 17:24:27
$dictionary["sco_ordencompra_sco_plandepagos"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sco_ordencompra_sco_plandepagos' => 
    array (
      'lhs_module' => 'SCO_OrdenCompra',
      'lhs_table' => 'sco_ordencompra',
      'lhs_key' => 'id',
      'rhs_module' => 'SCO_PlandePagos',
      'rhs_table' => 'sco_plandepagos',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sco_ordencompra_sco_plandepagos_c',
      'join_key_lhs' => 'sco_ordencompra_sco_plandepagossco_ordencompra_ida',
      'join_key_rhs' => 'sco_ordencompra_sco_plandepagossco_plandepagos_idb',
    ),
  ),
  'table' => 'sco_ordencompra_sco_plandepagos_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sco_ordencompra_sco_plandepagossco_ordencompra_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sco_ordencompra_sco_plandepagossco_plandepagos_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sco_ordencompra_sco_plandepagosspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sco_ordencompra_sco_plandepagos_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sco_ordencompra_sco_plandepagossco_ordencompra_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sco_ordencompra_sco_plandepagos_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sco_ordencompra_sco_plandepagossco_plandepagos_idb',
      ),
    ),
  ),
);