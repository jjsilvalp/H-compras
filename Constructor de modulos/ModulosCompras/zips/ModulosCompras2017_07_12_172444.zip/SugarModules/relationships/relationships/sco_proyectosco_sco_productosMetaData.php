<?php
// created: 2017-07-12 17:24:42
$dictionary["sco_proyectosco_sco_productos"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sco_proyectosco_sco_productos' => 
    array (
      'lhs_module' => 'SCO_ProyectosCO',
      'lhs_table' => 'sco_proyectosco',
      'lhs_key' => 'id',
      'rhs_module' => 'SCO_Productos',
      'rhs_table' => 'sco_productos',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sco_proyectosco_sco_productos_c',
      'join_key_lhs' => 'sco_proyectosco_sco_productossco_proyectosco_ida',
      'join_key_rhs' => 'sco_proyectosco_sco_productossco_productos_idb',
    ),
  ),
  'table' => 'sco_proyectosco_sco_productos_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sco_proyectosco_sco_productossco_proyectosco_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sco_proyectosco_sco_productossco_productos_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sco_proyectosco_sco_productosspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sco_proyectosco_sco_productos_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sco_proyectosco_sco_productossco_proyectosco_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sco_proyectosco_sco_productos_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sco_proyectosco_sco_productossco_productos_idb',
      ),
    ),
  ),
);