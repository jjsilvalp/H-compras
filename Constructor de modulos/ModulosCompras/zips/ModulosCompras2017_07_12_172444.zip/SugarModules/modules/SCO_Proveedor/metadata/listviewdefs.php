<?php
$module_name = 'SCO_Proveedor';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PRV_CODAIO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRV_CODAIO',
    'width' => '10%',
    'default' => true,
  ),
  'PRV_EMAIL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRV_EMAIL',
    'width' => '10%',
    'default' => true,
  ),
  'PRV_DIVISION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_PRV_DIVISION',
    'width' => '10%',
    'default' => true,
  ),
  'PRV_PAIS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PRV_PAIS',
    'width' => '10%',
    'default' => true,
  ),
  'PRV_CALIFICACION' => 
  array (
    'type' => 'int',
    'label' => 'LBL_PRV_CALIFICACION',
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
?>
