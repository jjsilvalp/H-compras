<?php
$module_name = 'SCO_OrdenCompra';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ORC_DFNOMEMP' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_ORC_DFNOMEMP',
    'width' => '10%',
    'default' => true,
  ),
  'ORC_DIVISION' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_ORC_DIVISION',
    'width' => '10%',
    'default' => true,
  ),
  'ORC_TIPOO' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'default' => true,
    'label' => 'LBL_ORC_TIPOO',
    'width' => '10%',
  ),
  'ORC_IMPORTET' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_ORC_IMPORTET',
    'width' => '10%',
    'default' => true,
  ),
  'ORC_TCMONEDA' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_ORC_TCMONEDA',
    'width' => '10%',
    'default' => true,
  ),
  'ORC_RESPONSABLE' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_ORC_RESPONSABLE',
    'id' => 'USER_ID_C',
    'link' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
?>
