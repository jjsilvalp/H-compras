<?php
$module_name = 'SCO_PlandePagos';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'PPG_FECHA' => 
  array (
    'type' => 'date',
    'label' => 'LBL_PPG_FECHA',
    'width' => '10%',
    'default' => true,
  ),
  'PPG_TIPO' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_PPG_TIPO',
    'width' => '10%',
  ),
  'PPG_HITO' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PPG_HITO',
    'width' => '10%',
    'default' => true,
  ),
  'PPG_PORC' => 
  array (
    'type' => 'decimal',
    'label' => 'LBL_PPG_PORC',
    'width' => '10%',
    'default' => true,
  ),
  'PPG_MONTO' => 
  array (
    'type' => 'currency',
    'label' => 'LBL_PPG_MONTO',
    'currency_format' => true,
    'width' => '10%',
    'default' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
?>
