<?php
$module_name = 'SCO_Cnf_Aprobadores';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CNFAPRO_DIV' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_CNFAPRO_DIV',
    'width' => '10%',
    'default' => true,
  ),
);
?>
