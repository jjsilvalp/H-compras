<?php
$module_name='SCO_Productos';
$subpanel_layout = array (
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'SCO_Productos',
    ),
  ),
  'where' => '',
  'list_fields' => 
  array (
    'name' => 
    array (
      'type' => 'name',
      'link' => true,
      'width' => '45%',
      'vname' => 'LBL_NAME',
      'default' => true,
      'widget_class' => 'SubPanelDetailViewLink',
      'target_module' => NULL,
      'target_record_key' => NULL,
    ),
    'pro_fechaprev' => 
    array (
      'type' => 'date',
      'vname' => 'LBL_PRO_FECHAPREV',
      'width' => '10%',
      'default' => true,
    ),
    'pro_cantidad' => 
    array (
      'type' => 'int',
      'default' => true,
      'vname' => 'LBL_PRO_CANTIDAD',
      'width' => '10%',
    ),
    'pro_cantidadr' => 
    array (
      'type' => 'int',
      'default' => true,
      'vname' => 'LBL_PRO_CANTIDADR',
      'width' => '10%',
    ),
    'pro_cantidadt' => 
    array (
      'type' => 'int',
      'default' => true,
      'vname' => 'LBL_PRO_CANTIDADT',
      'width' => '10%',
    ),
    'pro_preciound' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_PRO_PRECIOUND',
      'width' => '10%',
      'default' => true,
    ),
    'pro_descuento' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_PRO_DESCUENTO',
      'width' => '10%',
      'default' => true,
    ),
    'pro_tipodesc' => 
    array (
      'type' => 'enum',
      'studio' => 'visible',
      'vname' => 'LBL_PRO_TIPODESC',
      'width' => '10%',
      'default' => true,
    ),
    'pro_subtotal' => 
    array (
      'type' => 'decimal',
      'vname' => 'LBL_PRO_SUBTOTAL',
      'width' => '10%',
      'default' => true,
    ),
    'remove_button' => 
    array (
      'width' => '2%',
      'vname' => 'LBL_REMOVE',
      'default' => true,
      'widget_class' => 'SubPanelRemoveButton',
    ),
  ),
);