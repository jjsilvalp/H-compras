<?php
 // created: 2017-07-12 17:25:24
$layout_defs["SCO_ProyectosCO"]["subpanel_setup"]['sco_proyectosco_sco_productos'] = array (
  'order' => 100,
  'module' => 'SCO_Productos',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SCO_PROYECTOSCO_SCO_PRODUCTOS_FROM_SCO_PRODUCTOS_TITLE',
  'get_subpanel_data' => 'sco_proyectosco_sco_productos',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
