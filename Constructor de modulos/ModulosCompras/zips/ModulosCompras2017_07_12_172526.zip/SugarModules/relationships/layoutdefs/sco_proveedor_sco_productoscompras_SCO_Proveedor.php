<?php
 // created: 2017-07-12 17:25:21
$layout_defs["SCO_Proveedor"]["subpanel_setup"]['sco_proveedor_sco_productoscompras'] = array (
  'order' => 100,
  'module' => 'SCO_ProductosCompras',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SCO_PROVEEDOR_SCO_PRODUCTOSCOMPRAS_FROM_SCO_PRODUCTOSCOMPRAS_TITLE',
  'get_subpanel_data' => 'sco_proveedor_sco_productoscompras',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
