<?php
// created: 2017-07-12 17:25:21
$dictionary["sco_proveedor_sco_ordencompra"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'sco_proveedor_sco_ordencompra' => 
    array (
      'lhs_module' => 'SCO_Proveedor',
      'lhs_table' => 'sco_proveedor',
      'lhs_key' => 'id',
      'rhs_module' => 'SCO_OrdenCompra',
      'rhs_table' => 'sco_ordencompra',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'sco_proveedor_sco_ordencompra_c',
      'join_key_lhs' => 'sco_proveedor_sco_ordencomprasco_proveedor_ida',
      'join_key_rhs' => 'sco_proveedor_sco_ordencomprasco_ordencompra_idb',
    ),
  ),
  'table' => 'sco_proveedor_sco_ordencompra_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'sco_proveedor_sco_ordencomprasco_proveedor_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'sco_proveedor_sco_ordencomprasco_ordencompra_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'sco_proveedor_sco_ordencompraspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'sco_proveedor_sco_ordencompra_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'sco_proveedor_sco_ordencomprasco_proveedor_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'sco_proveedor_sco_ordencompra_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'sco_proveedor_sco_ordencomprasco_ordencompra_idb',
      ),
    ),
  ),
);