<?php
// created: 2017-07-12 17:25:13
$dictionary["SCO_Productos"]["fields"]["sco_ordencompra_sco_productos"] = array (
  'name' => 'sco_ordencompra_sco_productos',
  'type' => 'link',
  'relationship' => 'sco_ordencompra_sco_productos',
  'source' => 'non-db',
  'module' => 'SCO_OrdenCompra',
  'bean_name' => false,
  'vname' => 'LBL_SCO_ORDENCOMPRA_SCO_PRODUCTOS_FROM_SCO_ORDENCOMPRA_TITLE',
);
