<?php
// created: 2017-07-12 17:25:21
$dictionary["SCO_Proveedor"]["fields"]["sco_proveedor_sco_ordencompra"] = array (
  'name' => 'sco_proveedor_sco_ordencompra',
  'type' => 'link',
  'relationship' => 'sco_proveedor_sco_ordencompra',
  'source' => 'non-db',
  'module' => 'SCO_OrdenCompra',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PROVEEDOR_SCO_ORDENCOMPRA_FROM_SCO_ORDENCOMPRA_TITLE',
);
