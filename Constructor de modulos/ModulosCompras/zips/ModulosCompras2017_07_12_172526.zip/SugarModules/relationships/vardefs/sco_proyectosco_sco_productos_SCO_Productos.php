<?php
// created: 2017-07-12 17:25:25
$dictionary["SCO_Productos"]["fields"]["sco_proyectosco_sco_productos"] = array (
  'name' => 'sco_proyectosco_sco_productos',
  'type' => 'link',
  'relationship' => 'sco_proyectosco_sco_productos',
  'source' => 'non-db',
  'module' => 'SCO_ProyectosCO',
  'bean_name' => false,
  'vname' => 'LBL_SCO_PROYECTOSCO_SCO_PRODUCTOS_FROM_SCO_PROYECTOSCO_TITLE',
  'id_name' => 'sco_proyectosco_sco_productossco_proyectosco_ida',
);
$dictionary["SCO_Productos"]["fields"]["sco_proyectosco_sco_productos_name"] = array (
  'name' => 'sco_proyectosco_sco_productos_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SCO_PROYECTOSCO_SCO_PRODUCTOS_FROM_SCO_PROYECTOSCO_TITLE',
  'save' => true,
  'id_name' => 'sco_proyectosco_sco_productossco_proyectosco_ida',
  'link' => 'sco_proyectosco_sco_productos',
  'table' => 'sco_proyectosco',
  'module' => 'SCO_ProyectosCO',
  'rname' => 'name',
);
$dictionary["SCO_Productos"]["fields"]["sco_proyectosco_sco_productossco_proyectosco_ida"] = array (
  'name' => 'sco_proyectosco_sco_productossco_proyectosco_ida',
  'type' => 'link',
  'relationship' => 'sco_proyectosco_sco_productos',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SCO_PROYECTOSCO_SCO_PRODUCTOS_FROM_SCO_PRODUCTOS_TITLE',
);
